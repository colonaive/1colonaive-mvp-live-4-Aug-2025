// Re-export from main supabase client file
export * from '../supabase'