import { useScrollToTop } from '../hooks/useScrollToTop';

export const ScrollToTop: React.FC = () => {
  useScrollToTop();
  return null;
};